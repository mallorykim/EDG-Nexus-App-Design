# Review method — API consumability & completeness audit for Nexus controls

Adapted from Ether's `consumability-review` skill. The harness-specific machinery
(ConsumerFixtures, Verify-ConsumerFixtures.ps1, PublicAPI.Shipped.txt) does not exist in
Nexus — verification here is `dotnet build -p:Platform=x64` + the manual checklist below.

---

## Two complementary reviews

**Review A — API Consumability:** is what we exposed genuinely bindable/observable/wireable?
**Review B — API Completeness:** did we expose everything a consumer needs?

A control can pass one and fail the other. Do B first (establishes the target surface),
then A (checks the implementation against that surface).

---

## Review A — Consumability rubric (per public settable property)

A property passes only if **all** of R1–R5 hold.

### R1 — is a `DependencyProperty`
The single most important check. Only a DP is bindable (`{x:Bind}`, `{Binding}`),
styleable, animatable, and observable. A plain CLR property is invisible to XAML consumers.

```csharp
public string Prop
{
    get => (string)GetValue(PropProperty);
    set => SetValue(PropProperty, value);
}
public static readonly DependencyProperty PropProperty =
    DependencyProperty.Register(nameof(Prop), typeof(string),
        typeof(NexusMyControl), new PropertyMetadata("default", OnPropChanged));
```

### R2 — round-trips
`GetValue` and the CLR wrapper must agree. Never cache in a backing field — always go
through `GetValue`/`SetValue`. A common failure mode: reading a field in the getter while
`SetValue` updates the DP — the two diverge after a binding sets the value.

### R3 — observable
`RegisterPropertyChangedCallback` must fire when the value changes. This is automatic for
correctly registered DPs. It silently breaks when you bypass `SetValue` (e.g. direct field
assignment inside a `PropertyChanged` callback).

### R4 — TwoWay where the user drives it
Properties that represent interactive state (a selection, toggle, input value) must support
`{x:Bind Prop, Mode=TwoWay}`. The control must call `SetValue` (not just update a visual)
when the user changes the value so the binding engine propagates it back to the ViewModel.

### R5 — documented
XML-doc comment on the property AND its `…Property` field. State the default value.
The class-level XML-doc should show a minimal binding example.

---

## Review A — Per-control contracts

### C1 — data / collection controls accept data
If the control shows a list: `ItemsSource` + template/path + a selection API that
round-trips. Test both directions: set in code AND set as a XAML attribute before content
exists (the markup order a real consumer uses). The latter is the one that breaks silently.

### C2 — interactions are listenable
Every user interaction a ViewModel might observe must raise a `public event EventHandler<T>`.
This is the event path; C3 is the binding path. Provide both.

```csharp
public event EventHandler<string>? ValueChanged;
```

### C3 — commands
Every user action must have an `ICommand` DependencyProperty with null-safe invocation:

```csharp
public ICommand? ConnectCommand
{
    get => (ICommand?)GetValue(ConnectCommandProperty);
    set => SetValue(ConnectCommandProperty, value);
}
public static readonly DependencyProperty ConnectCommandProperty =
    DependencyProperty.Register(nameof(ConnectCommand), typeof(ICommand),
        typeof(NexusMyControl), new PropertyMetadata(null));

// In the handler:
if (ConnectCommand?.CanExecute(parameter) is true)
    ConnectCommand.Execute(parameter);
```

### C4 — automation peer / UIA pattern
Each control's automation role must match its behavior. See `references/winui-gotchas.md`
for the correct UIA pattern per WinUI base type — they are NOT uniform, and picking the
wrong one fails at runtime without a compile-time warning.

---

## Review B — Property matrix (the core artifact)

Build this table before writing any XAML. One row per property or action.

| Property / Action | Type | Direction | R1? | C2/C3? | Verdict |
|---|---|---|---|---|---|
| `DeviceName` | `string` | OneWay | ✅ | — | ✅ |
| `ShowBattery` | `bool` | OneWay | ✅ | — | ✅ |
| `ConnectCommand` | `ICommand` | Action | ✅ | C3 ✅ | ✅ |
| `ValueChanged` | `EventHandler<string>` | C2 event | — | C2 ✅ | ✅ |
| `InternalHelper` | `string` | — | ❌ (CLR) | — | ❌ |

**Directions:**
- `OneWay` — VM sets, control renders
- `TwoWay` — VM sets AND control writes back on user interaction
- `Action` — VM triggers via `ICommand` DP
- C2 event — control raises to notify VM of user-initiated changes

**Verdict codes:**
- ✅ complete
- ⚠️ present but not bindable (CLR property — needs upgrade to DP)
- ❌ missing (gap to close before shipping)
- 🚫 intentionally excluded — write the reason + the consumer's alternative

**No ❌ or unexplained 🚫 before committing.** An ⚠️ is only acceptable temporarily
with a filed follow-up; it must not ship.

---

## Pass / fail gates

**Review A passes** when every public settable property passes R1–R5 (or has a written
non-DP exception), and C1–C4 hold or are explicit N/A.

**Review B passes** when there are no ❌ and no unexplained 🚫 rows.

**A control is ready to ship** only when it passes both AND
`dotnet build EDGNexusApp.csproj -p:Platform=x64` exits 0.

---

## Grounding rules

- Confirm the control's actual base type from its `class X : Y` declaration before writing
  the matrix. Don't trust a guess.
- Reference official sources for "expected" behavior: WinUI Gallery + microsoft-ui-xaml,
  at the WindowsAppSDK version pinned in the csproj.
- Never assert something passes that you haven't actually verified. If you ran the build,
  cite the exit code. If you read the code, cite `file:line`.
- Distinguish a genuine missing feature (❌) from a deliberate exclusion (🚫). Labelling a
  gap 🚫 without justification is not acceptable — name the consumer's alternative.

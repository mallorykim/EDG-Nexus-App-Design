# WinUI gotchas — Nexus control authoring & build

Hard-won notes on non-obvious traps when building Nexus UserControls in a WinUI 3 /
WindowsAppSDK project. Each entry names the symptom, the cause, and the fix.

Sources: Ether `lessons-learned.md` + `technical-gotchas.md` (harness-specific entries
removed); Nexus-specific traps discovered during library extraction (2026-09).

---

## WinUI control authoring

### WinUI UIA automation patterns are NOT uniform — pick the right one

Testing every control for the same UIA pattern will fail at runtime. The correct pattern
depends on the WinUI base type, not the visual appearance:

| Base / behavior | Correct UIA pattern | Notes |
|---|---|---|
| `Button` (EtherButton, any invoke-style button) | `IInvokeProvider` | |
| `CheckBox` | `IToggleProvider` | |
| `ToggleSwitch` | `IToggleProvider` | |
| `RadioButton` (each segment in a segmented control) | `ISelectionItemProvider` | `IsSelected` tracks checked state. **NOT Toggle** — RadioButton is single-select semantics |
| `ComboBox` / dropdown | `IExpandCollapseProvider` | Tracks `IsDropDownOpen` |
| `ListView` / tab navigation | `ISelectionProvider` | |
| `Slider` / progress bar / scroll bar | `IRangeValueProvider` | |
| Custom `ContentControl` hosting a segmented control | **no host Selection pattern** | Verify via the items' `ISelectionItemProvider`, not the host |

Symptom of wrong pattern: automation test throws `InvalidOperationException` at runtime;
no compile-time warning. Verify by calling `AutomationPeer.GetPattern(PatternInterface.X)`
and checking the return is non-null.

### WinUI TextBox text pattern is NATIVE, not managed

`TextBoxAutomationPeer.GetPattern(PatternInterface.Value)` **and**
`PatternInterface.Text` both return null in-process. The pattern is surfaced to
out-of-process UIA clients (Narrator, Accessibility Insights) natively.

For a C4 automation proof on a TextBox-hosting control, assert:
- `GetAutomationControlType() == AutomationControlType.Edit`
- `IsKeyboardFocusable() == true`
- `IsEnabled() == true`

Do **not** assert a managed `IValueProvider` or `ITextProvider`.

### CheckBox / RadioButton do not drive the `FocusStates` VSM group

If you compose a custom focus ring as `<VisualStateGroup x:Name="FocusStates">` inside a
control that hosts a `CheckBox` or `RadioButton`, **the group will not fire** — those WinUI
base classes use the system focus visual, not a `FocusStates` group.

**Fix:** drive the ring from code-behind. In `OnApplyTemplate`, grab the focus-ring part and
toggle its visibility in `OnGotFocus`/`OnLostFocus` when `FocusState == FocusState.Keyboard`.

`Button`, `ToggleSwitch`, and `ComboBox` **do** drive `FocusStates` — do not apply this
workaround to them.

### Selector item VSM state names differ by base type

When writing a custom item `ControlTemplate` for a single-select list, the `CommonStates`
names depend on the base:

- **`ListViewItem`** (`X : ListView`): `Normal, Selected, PointerOver, PointerOverSelected,
  PointerOverPressed, Pressed, PressedSelected` — `Selected` is LAST; `Disabled` is a
  separate `DisabledStates` group; no `SelectedUnfocused`.
- **`ListBoxItem`** (`X : ListBox`): `Normal, PointerOver, Pressed, Disabled, Selected,
  SelectedUnfocused, SelectedPointerOver, SelectedPressed` — `Selected` FIRST.

**Symptom of using the wrong set:** clicking while hovering doesn't show the selected state
(it appears only after the pointer leaves) because the control called
`GoToState("PointerOverSelected")` but the template only had `SelectedPointerOver`.

### A shared `Geometry` renders blank after ListView recycle / page re-nav

In WindowsAppSDK 2.3.1, `Geometry` derives from `DependencyObject` and **cannot be
frozen/cloned by the platform for safe reuse**. If the same `Geometry` instance is handed to
a second `PathIcon` after the first's visual tree is torn down (ListView container recycling,
or `Frame` re-creating a page with `NavigationCacheMode=Disabled`), the glyph renders
**blank** — the Content slot exists but nothing draws.

**Common hiding place:** an icon-library `Style`. After XAML load, the `Data` `Setter.Value`
is already a coerced `Geometry` object, not the original path string, so copying a Style or
its Setter.Value still shares the one instance.

**Fix:** deep-clone the geometry per instance and rebuild the icon in `OnApplyTemplate`.
Do not share `Geometry` objects across visual tree instances.

**Symptom:** icon shows on first visit, blank after navigating away and back. A
`ContentControl` using the same icon Style may not reproduce it (different timing) — that
is not proof it is safe. Re-navigate 2+ times to verify.

### A keyed `Style` on a custom control inherits the default style's min-size setters

An explicit keyed `Style` (no `BasedOn`) on an Ether control still inherits the control's
**default (implicit) style setters** for any property the keyed style does not set.

**Example:** `EtherButton`'s default style sets `MinWidth=108 MinHeight=46 Padding=20,12`.
A keyed caption style that sets only `Width=46 Height=40` still renders 108×46 because the
default style's `MinWidth`/`MinHeight` floor it.

**Fix:** pin `MinWidth`, `MinHeight`, and `Padding` explicitly in the keyed style.

**Symptom:** a reskinned small variant looks too wide/tall with big margins even when
`Spacing=0` — the default style is leaking.

---

## WinUI 3 build & toolchain (Nexus-specific)

### WMC0610 — intra-library UserControl cross-reference crashes XBF generation

**Symptom:** `XamlCompiler error WMC0610: The XAML Binary Format (XBF) generator reported
syntax error '0xc00cee3c'` when the app builds, attributed to `EDGNexusApp.csproj`.

**Cause:** `NexusActionBar.xaml` contained `<nexus:NexusBatteryChip/>`. The WinUI 3 XAML
toolchain pulls source XAML from all ProjectReference libraries and re-processes it in the
consuming app's context. When it encounters a reference to another UserControl *in the same
library*, it cannot resolve the cross-reference and the XBF generator fails.

**Fix:** do NOT reference other `NexusApp.Controls` UserControls via inline XAML markup
inside the library. Inline the visual directly, or compose in code-behind:
```csharp
// code-behind — safe
var chip = new NexusBatteryChip();
MyPanel.Children.Add(chip);
```

**Rule in AGENTS.md:** "Do NOT reference other Nexus UserControls inside a Nexus
UserControl's XAML via `<nexus:OtherControl>`."

### PRI175/PRI277 duplicate-entry error

**Symptom:** `WINAPPSDKGENERATEPROJECTPRIFILE : error PRI277: Conflicting values for
resource 'Files/Nexus.Components/Controls/NexusTopBar.xbf'` during the app build.

**Cause:** `Nexus.Components/` lives inside the app's directory tree. The SDK's default
`**\*.xaml` glob in the app project picks up the Nexus control XAML files directly AND
they also come in via the ProjectReference — producing two XBF entries for the same path.

**Fix (already applied in `EDGNexusApp.csproj`):**
```xml
<ItemGroup>
  <Page Remove="Nexus.Components\**\*" />
  <Compile Remove="Nexus.Components\**\*" />
  <None Remove="Nexus.Components\**\*" />
  <EmbeddedResource Remove="Nexus.Components\**\*" />
  <Content Remove="Nexus.Components\**\*" />
</ItemGroup>
```
Do not remove these lines. If you add a new sub-project inside the app's directory tree,
apply the same pattern.

### CS0436 — spurious duplicate type-definition warnings

**Symptom:** `warning CS0436: The type 'X' in '…g.i.cs' conflicts with the imported type
'X' in 'Nexus.Components.dll'` across many XAML-generated files.

**Cause:** WinUI 3's XAML type-info generator pulls source files from referenced library
projects into the consuming app's compilation context, creating apparent duplicate type
definitions. The binary is correct; the warning is spurious.

**Fix (already applied in `EDGNexusApp.csproj`):**
```xml
<NoWarn>$(NoWarn);CS0436</NoWarn>
```

### Stale obj/ or bin/ causes cascading failures

After changing a XAML file's `x:Class`, moving a file, or removing a `<Page Update>` entry,
the old `.g.i.cs` files remain in `obj/` and conflict with the new build.

**Fix:** full clean before building:
```powershell
Remove-Item obj, bin, Nexus.Components\obj, Nexus.Components\bin -Recurse -Force
dotnet build EDGNexusApp.csproj -p:Platform=x64
```

Do not treat a failure after a structural XAML change as a code bug until you have run
a full clean build.

### MSB4276 on fresh restore (dotnet workload)

**Symptom:** `MSB4276 WorkloadAutoImportPropsLocator Sdk dir not found` on a fresh restore
(after deleting obj/bin).

**Fix:** run `dotnet workload restore EDGNexusApp.slnx` once, then build. Incremental
builds (restore skipped) do not hit it.

---
name: build-nexus-control
description: >-
  Use this skill whenever the task involves creating a new Nexus component, reviewing an existing
  Nexus control for MVVM completeness, or auditing whether a Nexus control is genuinely bindable
  and consumable from a ViewModel — even if the user doesn't use those exact words.
---

# Building a Nexus component

This skill captures the end-to-end process for writing a **new, MVVM-compatible Nexus control**
that lives in `Nexus.Components/Controls/`. Read this before writing any new control — or before
reviewing an existing one for API completeness.

> **Reference files — load as needed, not all upfront:**
> - [`references/review-method.md`](references/review-method.md) — full R1–R5 rubric, C1–C4
>   contracts, property matrix format, pass/fail gates, and grounding rules. Load when running
>   a formal API audit (Step 2) or when the consumability of an existing control is in question.
> - [`references/winui-gotchas.md`](references/winui-gotchas.md) — WinUI UIA patterns per base
>   type, authoring traps (Geometry recycling, VSM state names, keyed Style min-size leaks), and
>   Nexus build-toolchain issues (WMC0610, PRI duplicates, CS0436, stale obj/). Load before
>   touching automation peers, icon rendering, or when hitting an unexpected build error.

## Core principle: use WinUI primitives, don't reinvent them

This mirrors the rule from the Ether library that owns the controls Nexus wraps:

> **If the visual or behavior you need can be composed from existing WinUI/Ether primitives,
> compose them. Do not hand-author behavior the platform already provides.**

Nexus controls are **UserControls** (not ControlTemplate reskins), so they compose WinUI
elements and Ether controls rather than subclassing. The same honesty applies: selection,
keyboard navigation, focus, accessibility, and state transitions come for free when you use
the right WinUI host element. Always check:

- **WinUI Gallery** — usage, patterns, expected behavior:
  https://github.com/microsoft/WinUI-Gallery
- **microsoft-ui-xaml** — official control templates, VSM state names, automation peers:
  https://github.com/microsoft/microsoft-ui-xaml

## Step 1 — read the template first

`Nexus.Components/NEXUS_CONTROL_TEMPLATE.md` is the canonical XAML + code-behind skeleton.
Copy it before writing a single line. The template encodes all MVVM requirements and
WinUI-specific gotchas so you don't rediscover them.

## Step 2 — ground in the Figma design before writing any code

Every Nexus control is spec'd in Figma. **Do not start the API design or XAML until you have
run all three Figma MCP calls below, in order.** Skipping any of them causes invented token
names, wrong background colours, or layouts that match a generic mental model rather than the
actual design.

### Required sequence — all three, in this order

**1. `get_screenshot` — visual ground truth (run this first, not last)**

Get the screenshot *before* writing any code — not as a QA afterthought. The image
immediately answers questions that no metadata call can: Is the container background neutral
or status-tinted? Does severity manifest through background colour or icon alone? Are there
visible borders? One screenshot prevents entire categories of wrong assumptions. (The NexusAlert
background bug — `status/danger/bg` applied when the design uses `background/surface-raised` —
was caught only when the screenshot was finally checked *after* building. Had it been checked
first, the bug would never have existed.)

**2. `get_metadata` — layout and hierarchy**

Walk the node tree to understand columns, rows, nesting, and element sizes. Map every Figma
frame to a WinUI element (outer frame → `Border`, row container → `StackPanel`/`Grid`, etc.).
Note exact pixel gaps and padding values — you will resolve them to Ether spacing tokens next.

**3. `get_variable_defs` — exact token names for every fill, stroke, and typography style**

For every coloured, spaced, or typed element visible in the screenshot, pull the Figma
variable definition. **Never infer a token name from the Ether token-system naming patterns —
`get_variable_defs` is the only authoritative source.** A fill you guess as `status/danger/bg`
may actually be `background/surface-raised`; only the variable definition tells you which. Same
applies to spacing, corner radius, and font style.

### What to record before moving to Step 3

Produce a mapping table. Only tokens that appear in `get_variable_defs` output belong here;
use a literal value only after confirming no token exists for that property.

| Element | Figma variable | Ether XAML key |
|---|---|---|
| Container background | e.g. `background/surface-raised` | `{ThemeResource background/surface-raised}` |
| Container border colour | e.g. `border/subtle` | `{ThemeResource border/subtle}` |
| Icon foreground (info) | e.g. `status/info/fg` | `{ThemeResource status/info/fg}` |
| Padding (all sides) | e.g. `spacing/16` → `space/md` | `{StaticResource PaddingMd}` |
| … | … | … |

---

## Step 3 — design the API surface (Review B: completeness)

Before writing any XAML, list every piece of state and every action the control exposes.
Use a property matrix. Columns: **Property/Action | Type | Direction | Notes**.

Verdicts per row:
- ✅ will be a `DependencyProperty` / `ICommand` DP
- 🚫 intentionally excluded — write the reason and the consumer's alternative
- ❌ missing (gap to close before shipping)

**Directions:**
- `OneWay` — VM → control (read-only state the VM sets, e.g. a label text)
- `TwoWay` — VM ↔ control (user-interactive value, e.g. a selection or toggle)
- `OneWayToSource` — rare; only if the control surfaces computed state back to the VM
- `Action` — VM → control via `ICommand`; name as `<Verb>Command`

**No ❌ or unexplained 🚫 rows before shipping.**

## Step 4 — implement to the MVVM rubric (Review A: consumability)

Every public property must pass **all five checks** (R1–R5). Every action must pass C3.
Every interactive/observable behavior must pass C2.

### R1 — is a `DependencyProperty`
```csharp
public string MyProp
{
    get => (string)GetValue(MyPropProperty);
    set => SetValue(MyPropProperty, value);
}
public static readonly DependencyProperty MyPropProperty =
    DependencyProperty.Register(nameof(MyProp), typeof(string),
        typeof(NexusMyControl), new PropertyMetadata("default", OnMyPropChanged));
```
A plain CLR property is **invisible** to `{x:Bind}`, `{Binding}`, `Style`, and animation.
R1 is the single most important check — if a property fails R1, it fails everything.

### R2 — round-trips
`GetValue` and the CLR wrapper must agree. Don't cache the value in a field; always go through `GetValue`/`SetValue`.

### R3 — observable
`RegisterPropertyChangedCallback` must fire when the value changes. This is automatic for
correctly registered DPs; it breaks when you bypass `SetValue` (e.g. field assignment).

### R4 — TwoWay where the user drives it
Properties that represent interactive state (a selection, an input value, a toggle) must
support `{x:Bind Prop, Mode=TwoWay}`. This means the control must call `SetValue` (not just
update a visual) when the user changes the value, so the binding engine picks it up.

### R5 — documented
XML-doc comment on the property and its `…Property` field. State the default value.
Include a one-line binding example on the class XML-doc comment.

### C2 — interactions are listenable
Raise a `public event EventHandler<T>` for every user interaction that a VM might observe.
This is the event path; the `ICommand` path (C3) is the binding path. Provide both.

### C3 — ICommand for every action
```csharp
public ICommand? ConnectCommand
{
    get => (ICommand?)GetValue(ConnectCommandProperty);
    set => SetValue(ConnectCommandProperty, value);
}
public static readonly DependencyProperty ConnectCommandProperty =
    DependencyProperty.Register(nameof(ConnectCommand), typeof(ICommand),
        typeof(NexusMyControl), new PropertyMetadata(null));
```
Invoke with the null-safe pattern (same as WinUI's `Button`):
```csharp
if (ConnectCommand?.CanExecute(parameter) is true)
    ConnectCommand.Execute(parameter);
```

## Step 5 — XAML rules

1. **All tokens from Ether** — `{ThemeResource}` for semantic brushes/colors (they flip with
   light/dark); `{StaticResource}` for structural tokens (spacing, radii, typography styles).
   Never hardcode a color or spacing value.

2. **Do NOT reference other `NexusApp.Controls` UserControls via XAML markup** (e.g.
   `<nexus:OtherControl/>`). The WinUI 3 toolchain cannot handle intra-library UserControl
   cross-references in a ProjectReference context and will produce `WMC0610` / XBF error.
   **Fix:** inline the visual directly, or compose in code-behind via `new OtherControl()`.

3. **No business logic in the control.** The control handles visual state, animation, and
   user interactions. A ViewModel handles data, decisions, and side effects.

4. **`xmlns:controls="using:Ether.DesignSystem.Controls"`** for Ether controls.
   **`xmlns:nexus="using:NexusApp.Controls"`** is available in consuming pages — not inside
   the library itself (see rule 2 above).

## Step 6 — build verification

The only supported build target is **x64**. No `AnyCPU` or `x86`.

```powershell
# From the repo root:
dotnet build EDGNexusApp.csproj -p:Platform=x64

# Full clean when something feels stale:
Remove-Item obj, bin, Nexus.Components\obj, Nexus.Components\bin -Recurse -Force
dotnet build EDGNexusApp.csproj -p:Platform=x64
```

**Green = 0 errors.** The 2 SourceLink warnings from EtherDesignLibrary are pre-existing and
harmless — do not treat them as failures.

## Step 7 — the Gallery (auto by default; write a real page when it matters)

A new control needs **zero** Gallery work to be browsable: `NexusControlDiscovery.cs`
reflects over `Nexus.Components` at startup and auto-generates a fallback page
(`Views/AutoControlPage.xaml(.cs)`) for any control not already registered in
`ComponentCatalog.ManualNexusControlEntries` — live specimen + editors for every
`string`/`bool`/`int` DP the control declares. The nav label gets an "(auto)" suffix.

The auto page can't show `ICommand`/enum/complex properties, a curated description, or
STATES swatches, so write a real page in the same PR when the control deserves one:

1. Copy an existing page under `Nexus.Components.Gallery\Views\NexusControls\` (e.g.
   `NexusBatteryChipPage.xaml(.cs)` for a simple string-property control,
   `NexusActionBarPage.xaml(.cs)` for one with a bool + a string) as your starting point.
2. Root the page in a `views:ComponentPage` (`Title`, `Description`); wrap the live specimen
   in a `views:ControlExample` with `SourceXaml` set to the copy-paste snippet.
3. Wire every settable property to a plain WinUI input (`TextBox`/`CheckBox`) in
   `ComponentPage.InteractiveControls` so it's actually adjustable at runtime — this is a real
   exercise of R4 (TwoWay-capable), not just a visual smoke test. No Ether-specific input
   controls are needed for this.
4. Register the page's `Type` **and** `ControlType:` (so discovery skips it) as one line in
   `Nexus.Components.Gallery\ComponentCatalog.cs`'s `ManualNexusControlEntries`.
5. `dotnet build Nexus.Components.Gallery\Nexus.Components.Gallery.csproj -p:Platform=x64`
   then run it and confirm the page renders and the inputs actually update the specimen.

## Step 8 — pre-commit checklist

- [ ] `get_screenshot` run **before** writing any XAML — visual ground truth confirmed
- [ ] `get_metadata` run — layout, hierarchy, and gaps recorded
- [ ] `get_variable_defs` run — every fill, stroke, and typography token confirmed (no guessed names)
- [ ] Token mapping table produced before implementing (Figma variable → Ether XAML key)
- [ ] Every settable state is a `DependencyProperty` (R1)
- [ ] `GetValue`/`SetValue` used exclusively — no field-cached values (R2, R3)
- [ ] User-interactive properties support `TwoWay` binding (R4)
- [ ] XML-doc on every public DP and its `…Property` field, with default stated (R5)
- [ ] Every user action has a `public event` (C2) AND an `ICommand` DP (C3)
- [ ] `ICommand` invocation uses the null-safe `?.CanExecute() / .Execute()` pattern
- [ ] No `<nexus:OtherControl>` inline XAML reference to another Nexus UserControl (WMC0610)
- [ ] All colors/spacing/typography use Ether `{ThemeResource}` or `{StaticResource}` tokens
- [ ] No business logic in the control — purely visual/interaction behavior
- [ ] Control works with literal XAML values (no VM required, e.g. for gallery/design-time use)
- [ ] `dotnet build EDGNexusApp.csproj -p:Platform=x64` — 0 errors
- [ ] Control shows up in the Gallery (auto-fallback is fine for a first pass; a real page
      under `Views/NexusControls/` + `ManualNexusControlEntries` registration is recommended
      once its API is stable)

## Consumer ViewModel pattern (reference)

Nexus controls are consumed by ViewModels using `CommunityToolkit.Mvvm` (available in the
app project). The control itself does **not** depend on the toolkit — only the consuming VM does.

```csharp
// In the app (not in Nexus.Components)
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

public partial class MyPageViewModel : ObservableObject
{
    [ObservableProperty] private string _deviceName = "Webcam Pro";
    [ObservableProperty] private bool _showBattery = true;

    [RelayCommand]
    private void Connect() { /* backend call */ }

    [RelayCommand]
    private void Forget() { /* backend call */ }
}
```

```xml
<!-- In the page XAML -->
<nexus:NexusMyControl
    DeviceName="{x:Bind ViewModel.DeviceName}"
    ShowBattery="{x:Bind ViewModel.ShowBattery}"
    ConnectCommand="{x:Bind ViewModel.ConnectCommand}"
    ForgetCommand="{x:Bind ViewModel.ForgetCommand}"/>
```

## Key files

| File | Purpose |
|---|---|
| `Nexus.Components/NEXUS_CONTROL_TEMPLATE.md` | Copy-paste skeleton for a new control |
| `Nexus.Components/Nexus.Components.csproj` | Library project — no `<Page>` entries needed for new controls |
| `EDGNexusApp.csproj` | App project — already excludes `Nexus.Components/**` from SDK glob |
| `Nexus.Components.Gallery/ComponentCatalog.cs` | Gallery nav tree — `ManualNexusControlEntries` for hand-written pages |
| `Nexus.Components.Gallery/Views/NexusControls/` | One `<Control>Page.xaml(.cs)` per hand-written control page |
| `Nexus.Components.Gallery/NexusControlDiscovery.cs` | Reflection fallback — auto-pages any control not in `ManualNexusControlEntries` |
| `Nexus.Components.Gallery/Views/AutoControlPage.xaml(.cs)` | The generic page discovery uses for uncataloged controls |
| `AGENTS.md` | Build commands, architecture overview, namespace map |
